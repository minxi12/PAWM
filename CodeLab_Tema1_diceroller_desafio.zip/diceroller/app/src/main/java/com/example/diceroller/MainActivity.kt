package com.example.diceroller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
//No olvida de importar la libreria
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    //onCreate: un metodo predefinido tiene la fucnon de constructor -> metodos de coclo de vida
    //MainActicity -> donde difine las partes interacticas de la app -> evento del boton...
    //findViewById

    //var -> un contenedor para guardar imagen, reducir la llamada
    //var diceImage : ImageView? = null -> complicacion del codigo, porque necesita verificar si esta null

    //lateinit -> el compilador se iniciliza antes de hacer la operacion con el variable(como un varible no anulable)
    lateinit var diceImage : ImageView
    lateinit var diceImage2 : ImageView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rollButton: Button = findViewById(R.id.roll_button)
        //rollButton: nombre de la referencia; Button: tipo de la vista
        rollButton.setOnClickListener { rollDice() }
    }

    //??? El tipo a devolver == Int, ahora esta return una "Ruta A LA IMAGEN"
    //Tipo de datos a devolver: Unit(por defecto == void(Java))
    private fun getRandomDiceImage() : Int {
        val randomInt = (1..6).random()
        //Seleccion de foto y se guarda en variable con valor de la foto
        return when (randomInt){
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }

    }

    private fun rollDice(){
        //快速的为用户显示少量的信息。 Toast 在应用程序上浮动显示信息给用户，它永远不会获得焦点，
        // 不影响用户的输入等操作，主要用于 一些帮助 / 提示。
        //Contexto: 上下文， 子程序之于程序，进程之于操作系统，甚至app的一屏之于app，都是一个道理。
        //程序执行了部分到达子程序，子程序要获得结果，要用到程序之前的一些结果
        //Toast.makeText(this, "button clicked", Toast.LENGTH_SHORT).show()

        /*
        val resultText: TextView = findViewById(R.id.result_text)
        resultText.text = "Dice Rolled!"
        resultText.text = randomInt.toString()
        */
        //Generar un rango de numero aleatorio entre (1-6)
        val randomInt = (1..6).random()
        val randomInt2 = (1..6).random()


        //findViewById -> proceso de busqueda costosa, porque se busca todas las jerarquias
        //del Android -> intenta llamar la funicon 1 vez y se guarda para uso futuro
        val diceImage: ImageView = findViewById(R.id.dice_image)
        val diceImage2 : ImageView = findViewById(R.id.dice_image2)

        //Cambio de fotos
        diceImage.setImageResource(getRandomDiceImage())
        diceImage2.setImageResource(getRandomDiceImage())
    }
}